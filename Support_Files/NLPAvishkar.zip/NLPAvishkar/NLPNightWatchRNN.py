# -*- coding: utf-8 -*-
"""
Created on Thu Mar  5 01:54:38 2020

@author: kumarsis
"""



from nltk import WordNetLemmatizer
from nltk.stem import PorterStemmer
from nltk.stem import SnowballStemmer
from nltk.tokenize  import RegexpTokenizer
from nltk.tokenize  import word_tokenize
from nltk.tokenize import WordPunctTokenizer
from nltk.corpus  import stopwords
import pandas as pd
from tensorflow import keras
import tensorflow as tf
import re

from numpy import array
from numpy import asarray
from numpy import zeros


from tensorflow.keras.preprocessing.text import Tokenizer


reg_tokenizer=RegexpTokenizer(r'\w+')
stopword=stopwords.words('english')

wordLemmatize=WordNetLemmatizer()

ds=pd.read_excel("testCases.xlsx")
ds=ds.fillna(value='none')
test_steps=ds.iloc[: ,0].values.tolist()
#print(test_steps)
lemmatised_tokens_verb_List=[]

tokens=[]
new_tokens=[]
labels = array([1,2,3,4,5,6,7,8,9,10])

def preprocess_text(sen):
    # Remove punctuations and numbers
    sentence = re.sub('[^a-zA-Z]', ' ', sen)
    # Single character removal
    sentence = re.sub(r"\s+[a-zA-Z]\s+", ' ', sentence)
    # Removing multiple spaces
    sentence = re.sub(r'\s+', ' ', sentence)
    return sentence


docs = []
sentences = list(ds["test"])
for sen in test_steps:
    docs.append(preprocess_text(sen))

print(docs)    
t = Tokenizer()
t.fit_on_texts(docs)
vocab_size = len(t.word_index) + 1
print(vocab_size)
# integer encode the documents
encoded_docs = t.texts_to_sequences(docs)
print(encoded_docs)
# pad documents to a max length of 4 words
max_length = 10
padded_docs = tf.keras.preprocessing.sequence.pad_sequences(encoded_docs, maxlen=max_length, padding='post')
print(padded_docs)

# load the whole embedding into memory
embeddings_index = dict()
f = open('glove.6B.100d.txt' ,encoding="utf8")
for line in f:
	values = line.split()
	word = values[0]
	coefs = asarray(values[1:], dtype='float32')
	embeddings_index[word] = coefs
f.close()
print('Loaded %s word vectors.' % len(embeddings_index))
# create a weight matrix for words in training docs
embedding_matrix = zeros((vocab_size, 100))
print(embedding_matrix)
for word, i in t.word_index.items():
	embedding_vector = embeddings_index.get(word)
	if embedding_vector is not None:
		embedding_matrix[i] = embedding_vector
# define model
        
model = tf.keras.Sequential([
tf.keras.layers.Embedding(vocab_size, 100, weights=[embedding_matrix], input_length=6,
                          trainable=False),
tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(64)),
tf.keras.layers.Dense(64, activation='sigmoid'),
tf.keras.layers.Dense(6)
])
print("after model")

model.compile(loss=tf.keras.losses.BinaryCrossentropy(from_logits=True),
              optimizer=tf.keras.optimizers.Adam(1e-4),
              metrics=['accuracy'])
print("after model compile")
# fit the model
model.fit(padded_docs, labels, epochs=50, verbose=0)
# evaluate the model
loss, accuracy = model.evaluate(padded_docs, labels, verbose=0)
print('Accuracy: %f' % (accuracy*100))


# from gensim.scripts.glove2word2vec import glove2word2vec
# glove_input_file = 'glove.6B.100d.txt'
# word2vec_output_file = 'glove.6B.100d.txt.word2vec'
# glove2word2vec(glove_input_file, word2vec_output_file)