# -*- coding: utf-8 -*-
"""
Created on Sat Apr 18 19:41:56 2020

@author: kumarsis
"""

import tensorflow as tf
import sklearn
import pandas as pd
import nltk
import numpy as np
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense,Flatten,LSTM,Conv2D,Conv1D,MaxPooling1D, MaxPooling2D,Dropout,Activation
from sklearn.manifold import TSNE
from nltk.corpus import stopwords
#from tensorflow.keras.layers.Embedding import Embedding
import NLPGensim as nlpg
from nltk.tokenize  import RegexpTokenizer
from nltk.tokenize  import word_tokenize
from textblob import TextBlob

from nltk import WordNetLemmatizer







data=pd.read_excel("C:/myProjects/NLP/Avishkar_Data.xlsx")
data=data.fillna(value='none')
print(data)
print(data.columns)
data=data[['Name ','Attribute ']]
print(data)
label='Click,link,Validate,Browser,Right,Dropdown,Accept,Input'
def encode_label(label):
    if label.lower()=='click':
        return 0
    elif label.lower()=='link':
        return 1
    elif label.lower()=='validate':
        return 2
    elif label.lower()=='browser':
        return 3
    elif label.lower()=='right':
        return 4
    elif label.lower()=='dropdown':
        return 5
    elif label.lower()=='accept':
        return 6
    elif label.lower()=='input':
        return 7
    else :
        return 8
    

test_steps=data['Name ']
data['Attribute '] = data['Attribute '].map(lambda x: encode_label(x))
reg_tokenizer=RegexpTokenizer(r'\w+')
stopword=stopwords.words('english')
wordLemmatize=WordNetLemmatizer()
def get_processed_test_steps():
    tokens=[]
    new_tokens=[]
    for value in test_steps:
        # value=get_corrected_Multiline_word_symspell(value)
        reg_tokens=reg_tokenizer.tokenize(value)   
        reg_text=" ".join(token for token in reg_tokens if token not in stopword)   
        word_tokens=word_tokenize(reg_text)
        tokens.append(word_tokens)
    
    for term in tokens:
        lemmatised_tokens_noun_List=[]
        for word in term:
            correction = TextBlob(word)
            ##This line is less accurate but is fast
            word=str(correction.correct())
            verb_word=wordLemmatize.lemmatize(word,pos='v')
            noun_word=wordLemmatize.lemmatize(verb_word,pos='n')
            lemmatised_tokens_noun_List.append(noun_word)
            noun_string=" ".join(x for x in lemmatised_tokens_noun_List)
        new_tokens.append(noun_string) 
    #print(type(new_tokens))
    #print(new_tokens)     
    return new_tokens 
processedTokens=get_processed_test_steps()
print(processedTokens)

data['Name ']=processedTokens
print(data['Name '])

vocabulary_size=40000
### Create sequence
vocabulary_size = 20000
tokenizer = Tokenizer(num_words= vocabulary_size)
tokenizer.fit_on_texts(data['Name '])
sequences = tokenizer.texts_to_sequences(data['Name '])
padded_data = pad_sequences(sequences, maxlen=50)
print(padded_data.shape)

embeddings_index = dict()
f = open('glove.6B.200d.txt',encoding="utf8")
for line in f:
    values = line.split()
    word = values[0]
    coefs = np.asarray(values[1:], dtype='float32')
    embeddings_index[word] = coefs
f.close()

embedding_matrix = np.zeros((vocabulary_size, 200))
for word, index in tokenizer.word_index.items():
    if index > vocabulary_size - 1:
        break
    else:
        embedding_vector = embeddings_index.get(word)
        if embedding_vector is not None:
            embedding_matrix[index] = embedding_vector
##############make each word its lowercase to test

import sklearn.model_selection as sk

#X_train, X_test, y_train, y_test = sk.train_test_split(data['Name '],data['Attribute '],test_size=0.33, random_state = 42)
model_glove=Sequential()
model_glove.add(tf.keras.layers.Embedding(vocabulary_size,200,input_length=50,
                          weights=[embedding_matrix],trainable=False))
model_glove.add(Dropout(0.2))
model_glove.add(Conv1D(64,5,activation='relu'))
model_glove.add(MaxPooling1D(pool_size=4))
model_glove.add(LSTM(100))
model_glove.add(Dense(1,activation='sigmoid'))
model_glove.compile(loss='binary_crossentropy',optimizer='sgd',metrics=['accuracy'])
print(data['Attribute '])
model_glove.fit(padded_data,data['Attribute '], validation_split=0.2, epochs=5)

