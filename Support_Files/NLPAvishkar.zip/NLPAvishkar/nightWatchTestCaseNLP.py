# -*- coding: utf-8 -*-
"""
Created on Wed Feb 26 01:52:28 2020

@author: kumarsis
"""

import nltk
from nltk import WordNetLemmatizer
from nltk.stem import PorterStemmer
from nltk.stem import SnowballStemmer
from nltk.tokenize  import RegexpTokenizer
from nltk.tokenize  import word_tokenize
from nltk.tokenize import WordPunctTokenizer
from nltk.corpus  import stopwords
import pandas as pd
from tensorflow import keras
import tensorflow as tf
from tensorflow.keras.preprocessing.text import Tokenizer


reg_tokenizer=RegexpTokenizer(r'\w+')
stopword=stopwords.words('english')

wordLemmatize=WordNetLemmatizer()

ds=pd.read_excel("testCases.xlsx")
ds=ds.fillna(value='none')
test_steps=ds.iloc[: ,0].values.tolist()
#print(test_steps)
lemmatised_tokens_verb_List=[]

tokens=[]
new_tokens=[]
for value in test_steps:
    reg_tokens=reg_tokenizer.tokenize(value)   
    reg_text=" ".join(token for token in reg_tokens if token not in stopword)   
    word_tokens=word_tokenize(reg_text)
    tokens.append(word_tokens)
#print(tokens)  

for term in tokens:
    lemmatised_tokens_noun_List=[]
    for word in term:
        verb_word=wordLemmatize.lemmatize(word,pos='v')
        noun_word=wordLemmatize.lemmatize(verb_word,pos='n')
        lemmatised_tokens_noun_List.append(noun_word)
    new_tokens.append(lemmatised_tokens_noun_List) 
print(new_tokens)    
        
vocabulary_size = 20000
tokenizer = Tokenizer(num_words= vocabulary_size)
tokenizer.fit_on_texts(new_tokens)
#sequences = tokenizer.texts_to_sequences(df['text'])
# ####testing keras word embedding
# docs=new_tokens
# vocab_size=50
# encoded_docs=[tf.keras.preprocessing.text.one_hot(d,vocab_size) for d in docs] 
# print(encoded_docs) 
# max_length=6
# padded_docs=tf.keras.preprocessing.sequence.pad_sequences(encoded_docs,maxlen=max_length,padding='post')
# print(padded_docs)
    
    