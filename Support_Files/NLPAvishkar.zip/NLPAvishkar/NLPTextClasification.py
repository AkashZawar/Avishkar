# -*- coding: utf-8 -*-
"""
Created on Sat Mar  7 00:32:19 2020

@author: kumarsis
"""

import nltk
from nltk.tokenize import WordPunctTokenizer
from nltk.tokenize import RegexpTokenizer
from nltk import WordNetLemmatizer
import pandas as pd
import sklearn
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.preprocessing.text import Tokenizer
import tensorflow_datasets as tfds

dataset,info=tfds.load('imdb_reviews/subwords8k', with_info=True,
                          as_supervised=True)
train_dataset, test_dataset=dataset['train'],dataset['test']
#print(info)
encoder = info.features['text'].encoder
sample_string = 'Hello TensorFlow.'

encoded_string = encoder.encode(sample_string)
print('Encoded string is {}'.format(encoded_string))
original_string = encoder.decode(encoded_string)
print('The original string: "{}"'.format(original_string))
for index in encoded_string:
  print('{} ----> {}'.format(index, encoder.decode([index])))
docs=[]  

wordtoken=WordPunctTokenizer()
docs=wordtoken.tokenize(sample_string)  

t = Tokenizer()
t.fit_on_texts(docs)
vocab_size = len(t.word_index) + 1
print(vocab_size)
print(docs)
# integer encode the documents
encoded_docs = t.texts_to_sequences(docs) 
print(encoded_docs) 
BUFFER_SIZE = 10000
BATCH_SIZE = 64


print(type(train_dataset))
train_dataset = train_dataset.shuffle(BUFFER_SIZE,padded_shapes=[None])

train_dataset = train_dataset.padded_batch(BATCH_SIZE,padded_shapes=[None])
print(type(train_dataset))

test_dataset = test_dataset.padded_batch(BATCH_SIZE,padded_shapes=[None]) 
print(type(test_dataset)) 