
from selenium import webdriver
import Nights_Watch_Functions as nw
import NLPGensim as gen
import pandas as pd


driver = webdriver.Chrome()
#driver.get("https://www.gmail.com")
driver.get("http://demo.automationtesting.in/Register.html")


#driver.maximize_window()


inputSteps=gen.get_processed_test_steps()
test_steps=inputSteps[0]
#print(test_steps)


locators=inputSteps[1]
arg_values=inputSteps[2]
df=pd.DataFrame(list(zip(test_steps, locators,arg_values)), 
               columns =['Test', 'locator','Value1'])
#print(df) 

#driver.find_element_by_xpath(to_xpath(field("search text"))).sendKeys("this is test")
# nw.input_text_field(driver,"email","multisonu@gmail.com")
# #driver.find_element_by_xpath("("+ to_xpath(button("Next"), exact=True)+")[1]").click()
# nw.click_button(driver,"Next")

                      
        
                            
                            



def select_Action(i,Driver,locator,value):
     switcher={
                "Input":nw.input_text_field(Driver,locator,value),
                "enter":nw.input_text_field(Driver,locator,value),
                "click":nw.click_button(Driver,locator),
                "checkbox":nw.select_checkbox(Driver,value,value),
                "dropdown":nw.select_Dropdown_value(Driver,value,value),
                # 4:'Thursday',
                # 5:'Friday',
                # 6:'Saturday'
             }
     return switcher.get(i,"Invalid day of week")
 
    
for test,locator,arg in zip((test_steps),(locators),(arg_values)):
    print(test)
    driver.implicitly_wait(1)
    if "click" in test:
        print("clicking")
        nw.click_button(driver,locator)
    elif "enter"  in test:
         print("entering")
         nw.input_text_field(driver,locator,arg)
    elif "input"  in test:
         print("inputing")
         nw.input_text_field(driver,locator,arg)
    elif "checkbox"  in test: 
         print("clicking checkbox")
         nw.select_checkbox(driver,locator,arg) 
    elif "dropdown"  in test:
         print("clicking dropdown")
         nw.select_Dropdown_value(driver,locator,arg)
    elif "radio"  in test:
         print("clicking radio button")     
         nw.select_radio_button(driver,locator,arg)
    elif "option"  in test:
         print("clicking option button")     
         nw.click_option(driver,arg)         
         #click_option(driver,option_value):
    else:
        print("Action Not found.Please write manually")




















