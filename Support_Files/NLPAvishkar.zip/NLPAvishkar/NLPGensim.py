# -*- coding: utf-8 -*-
"""
Created on Wed Mar 11 22:48:21 2020

@author: kumarsis
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Feb 26 01:52:28 2020

@author: kumarsis
"""


from nltk import WordNetLemmatizer
from nltk.tokenize  import RegexpTokenizer
from nltk.tokenize  import word_tokenize
from nltk.tokenize import WordPunctTokenizer
from nltk.corpus  import stopwords

import pandas as pd
from tensorflow import keras
import tensorflow as tf
from textblob import TextBlob
from tensorflow.keras.preprocessing.text import Tokenizer


reg_tokenizer=RegexpTokenizer(r'\w+')
stopword=stopwords.words('english')

wordLemmatize=WordNetLemmatizer()

ds=pd.read_excel("testCases.xlsx")
ds=ds.fillna(value='none')
test_steps=ds.iloc[: ,0].values.tolist()
locators=ds["locator"].values.tolist()
arg_values=ds["Value1"].values.tolist()
#print(test_steps)
lemmatised_tokens_verb_List=[]


####################implementng symspell for word segregation###
from symspellpy.symspellpy import SymSpell,Verbosity  # import the module

def get_segregated_text_symspell(text):
    # maximum edit distance per dictionary precalculation
    max_edit_distance_dictionary = 0
    prefix_length = 7
    # create object
    sym_spell = SymSpell(max_edit_distance_dictionary, prefix_length)
    # load dictionary
    dictionary_path = "frequency_dictionary_en_82_765.txt"
        
    bigram_path = "frequency_bigramdictionary_en_243_342.txt"
    # term_index is the column of the term and count_index is the
    # column of the term frequency
    if not sym_spell.load_dictionary(dictionary_path, term_index=0,
                                     count_index=1):
        print("Dictionary file not found")
    
    if not sym_spell.load_bigram_dictionary(dictionary_path, term_index=0,
                                            count_index=2):
        print("Bigram dictionary file not found")
    
    
    # a sentence without any spaces
    input_term = text
    
    result = sym_spell.word_segmentation(input_term)
    return result.corrected_string

##################implementing spelling correction in symspell####
##############################################################
def get_corrected_word_symspell(word):
    max_edit_distance_dictionary = 2
    prefix_length = 7
    max_edit_distance_lookup = 2
    # create object
    sym_spell = SymSpell(max_edit_distance_dictionary, prefix_length)
    # load dictionary
    dictionary_path = "frequency_dictionary_en_82_765.txt"
        
    bigram_path = "frequency_bigramdictionary_en_243_342.txt"
    
    # term_index is the column of the term and count_index is the
    # column of the term frequency
    if not sym_spell.load_dictionary(dictionary_path, term_index=0,
                                     count_index=1):
        print("Dictionary file not found")
        
    if not sym_spell.load_bigram_dictionary(bigram_path, term_index=0,
                                            count_index=2):
        print("Bigram dictionary file not found")
    
    
    # lookup suggestions for single-word input strings
    input_term = word  # misspelling of "members"
    # max edit distance per lookup
    # (max_edit_distance_lookup <= max_edit_distance_dictionary)
    
    suggestion_verbosity = Verbosity.CLOSEST  # TOP, CLOSEST, ALL
    suggestions = sym_spell.lookup(input_term, suggestion_verbosity,
                                   max_edit_distance_lookup)
    #print(suggestions)
    # display suggestion term, term frequency, and edit distance
    #for suggestion in suggestions:
       # print("{}, {}, {}".format(suggestion.term, suggestion.distance,
                                 # suggestion.count))
    #print(suggestions[0].term)
    return   suggestions[0].term 


def get_corrected_Multiline_word_symspell(word):
    max_edit_distance_dictionary = 2
    prefix_length = 7
    max_edit_distance_lookup = 2
    # create object
    sym_spell = SymSpell(max_edit_distance_dictionary, prefix_length)
    # load dictionary
    dictionary_path = "frequency_dictionary_en_82_765.txt"
        
    bigram_path = "frequency_bigramdictionary_en_243_342.txt"
    
    # term_index is the column of the term and count_index is the
    # column of the term frequency
    if not sym_spell.load_dictionary(dictionary_path, term_index=0,
                                     count_index=1):
        print("Dictionary file not found")
        
    if not sym_spell.load_bigram_dictionary(bigram_path, term_index=0,
                                            count_index=2):
        print("Bigram dictionary file not found")
    

    # lookup suggestions for multi-word input strings (supports compound
    # splitting & merging)
    input_term = (word)
    # # max edit distance per lookup (per single word, not per whole input string)
    max_edit_distance_lookup = 2
    suggestions = sym_spell.lookup_compound(input_term,
                                            max_edit_distance_lookup)
    # # display suggestion term, edit distance, and term frequency
    #for suggestion in suggestions:
        #print("{}, {}, {}".format(suggestion.term, suggestion.distance,
                                  # suggestion.count))
    return suggestions[0].term    

############################end of symspell implemenatation




tokens=[]
new_tokens=[]
def get_processed_test_steps():
    tokens=[]
    new_tokens=[]
    for value in test_steps:
        # print(value)
        # value=get_corrected_Multiline_word_symspell(value)
        # print(value)
        reg_tokens=reg_tokenizer.tokenize(value)   
        reg_text=" ".join(token for token in reg_tokens if token not in stopword)  
        
        word_tokens=word_tokenize(reg_text)
        tokens.append(word_tokens)
   # print(tokens)  
    
    for term in tokens:
        lemmatised_tokens_noun_List=[]
        for word in term:
            correction = TextBlob(word)
            ##This line is less accurate but is fast
            word=str(correction.correct())
            ###the below line is more accurate but is slow
            #word=str(get_corrected_word_symspell(word))
            #print(word)
            verb_word=wordLemmatize.lemmatize(word,pos='v')
            noun_word=wordLemmatize.lemmatize(verb_word,pos='n')
            lemmatised_tokens_noun_List.append(noun_word)
        new_tokens.append(lemmatised_tokens_noun_List) 
    #print(type(new_tokens))
    #print(new_tokens)     
    return new_tokens,locators,arg_values    
        

# ####################using word to vec and glove###########
from gensim.scripts.glove2word2vec import glove2word2vec
#from gensim
# glove_input_file = 'glove.6B.300d.txt'
# word2vec_output_file = 'glove.6B.300d.txt.word2vec'
# glove2word2vec(glove_input_file, word2vec_output_file)

from gensim.models import KeyedVectors
# # load the Stanford GloVe model
# filename = 'glove.6B.300d.txt.word2vec'
# model = KeyedVectors.load_word2vec_format(filename, binary=False)
# model.save("word2vec300.model")
model = KeyedVectors.load("word2vec300.model",mmap='r')
##############make each word its lowercase to test



# calculate: (king - man) + woman = ?
#result = model.most_similar(positive=['woman', 'king'], negative=['man'], topn=1)
#print(result)
#print(model.vocab)
#print(model.most_similar('computer'))    
#result = model.most_similar(positive="search field", topn=5)

#vector = model['computer'] 
#print(vector)
cosine=model.n_similarity(['search','field'],['search'])
print(cosine)    




#sequences = tokenizer.texts_to_sequences(df['text'])
# ####testing keras word embedding
# docs=new_tokens
# vocab_size=50
# encoded_docs=[tf.keras.preprocessing.text.one_hot(d,vocab_size) for d in docs] 
# print(encoded_docs) 
# max_length=6
# padded_docs=tf.keras.preprocessing.sequence.pad_sequences(encoded_docs,maxlen=max_length,padding='post')
# print(padded_docs)
    
    