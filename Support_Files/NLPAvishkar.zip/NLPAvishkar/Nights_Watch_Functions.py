# -*- coding: utf-8 -*-
"""
Created on Sun Mar 15 21:10:35 2020

@author: kumarsis
"""
import selenium
import xpath
from selenium import webdriver
from xpath.html import field
from xpath.html import checkbox
from xpath.html import select
from selenium.webdriver.common.keys import Keys
from xpath.html import button
from xpath.html import fillable_field
from xpath.html import radio_button
from xpath.html import link_or_button
from xpath.html import option
from xpath.renderer import to_xpath
from nltk.tokenize import WordPunctTokenizer
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.select import Select

def input_text_field(driver,field_name,input_text):
    inputFlag=0
    field_name_list=field_name.split()
    new_field_name_list=[]
    for term in field_name_list:
        Cap_term=term[0].upper()+("".join(x for x in term[1:]))
        new_field_name_list.append(Cap_term)
    field_name_string=" ".join(x for x in new_field_name_list)
    print(field_name_string) 
    elem = driver.find_elements_by_xpath(to_xpath(fillable_field(field_name)))
    print(len(elem))
    if len(elem) > 0 and inputFlag==0:
       if(elem[0].send_keys(input_text)==None): 
         inputFlag=1
         driver.find_element_by_tag_name("body").send_keys(Keys.TAB)
         print("clicking html outside locator")
    elif inputFlag==0:	     
        elem = driver.find_elements_by_xpath(to_xpath(fillable_field(field_name_string)))
        if len(elem) > 0 and inputFlag==0:
            if(elem[0].send_keys(input_text)==None): 
                 inputFlag=1
                 driver.find_element_by_tag_name("body").send_keys(Keys.TAB)
                 print("clicking html outside locator")
    if  inputFlag==0:    
        wordToken=WordPunctTokenizer()
        field_token_list=wordToken.tokenize(field_name) 
        field_name_list_unprocessed=wordToken.tokenize(field_name)
        for term in field_token_list:
            print(to_xpath(field(term)))
            elemTerm=driver.find_elements_by_xpath(to_xpath(fillable_field(term)))
            if len(elemTerm) > 0 and inputFlag==0:              
                if(elemTerm[0].send_keys(input_text)==None):
                    inputFlag=1
                    driver.find_element_by_tag_name("body").send_keys(Keys.TAB)
                    print("clicking html term outside locator")
                    break
						  
    if inputFlag==0:
                elementList=driver.find_elements_by_xpath("//*[contains(text(),'"+term+"')]")
                print(elementList[0])
                for ele in elementList: 
                     if(ele.is_displayed() and ele.is_enabled()): 
                        print("in here")
                        print("//*[contains(text(),'"+term+"')]")
                        ele.send_keys(input_text)
                        inputFlag=1
                        print("entering second last found")
                        break
                        #print("clicking last found")
    if inputFlag==0:    
                elementList=driver.find_elements_by_xpath("//*[contains(@*,'"+term+"')]")
                for ele in elementList: 
                     if(ele.is_displayed() and ele.is_enabled()): 
                        print("in here") 
                        ele.send_keys(input_text)
                        inputFlag=1  
                        print("entering last found")
                        break
                        #print("clicking last found")
                     else:
                         print("click last found.Please try different term")
    print("input flag is "+str(inputFlag)) 
def click_option(driver,option_value):
    inputFlag=0
    option_value_list=option_value.split()
    new_option_value_list=[]
    for term in option_value_list:
        Cap_term=term[0].upper()+("".join(x for x in term[1:]))
        new_option_value_list.append(Cap_term)
    option_value_string=" ".join(x for x in new_option_value_list)
    print(option_value_string) 
    elem = driver.find_elements_by_xpath(to_xpath(option(option_value_string)))
    if len(elem) > 0:
       if(elem[0].click()==None): 
         inputFlag=1
         driver.find_element_by_tag_name("body").send_keys(Keys.TAB)
         print("clicking html outside locator")
         
    wordToken=WordPunctTokenizer()
    option_token_list=wordToken.tokenize(option_value)
    option_value_list_unprocessed=wordToken.tokenize(option_value)
    for term in option_token_list:
            print(term)
            print(to_xpath(option(term)))
            elemTerm=driver.find_elements_by_xpath(to_xpath(option(term)))
            if len(elemTerm) > 0 and inputFlag==0:              
               if(elemTerm[0].click()==None):      
                   driver.find_element_by_tag_name("body").send_keys(Keys.TAB)
                   print("clicking html term outside locator")
                   break
            elif inputFlag==0:
                elementList=driver.find_elements_by_xpath("//*[contains(text(),'"+term+"')]")
                for ele in elementList: 
                     if(ele.is_displayed() and ele.is_enabled()): 
                        print("in here") 
                        ele.click()
                        inputFlag=1
                        print("entering second last found")
                        break
                        #print("clicking last found")
            elif inputFlag==0:    
                elementList=driver.find_elements_by_xpath("//*[contains(@*,'"+term+"')]")
                for ele in elementList: 
                     if(ele.is_displayed() and ele.is_enabled()): 
                        print("in here") 
                        ele.click()
                        inputFlag=1
                        print("entering last found")
                        break
                        #print("clicking last found")
                     else:
                         print("click last found.Please try different term")   
def click_button(driver,button_name):
    inputFlag=0
    button_name_list=button_name.split()
    new_button_name_list=[]
    for term in button_name_list:
        Cap_term=term[0].upper()+("".join(x for x in term[1:]))
        new_button_name_list.append(Cap_term)
    button_name_string=" ".join(x for x in new_button_name_list)
    print(button_name_string) 
    elem = driver.find_elements_by_xpath(to_xpath(button(button_name_string)))
    if len(elem) > 0:
       if(elem[0].click()==None): 
         inputFlag=1
         driver.find_element_by_tag_name("body").send_keys(Keys.TAB)
         print("clicking html outside locator")
         
    wordToken=WordPunctTokenizer()
    button_token_list=wordToken.tokenize(button_name)
    button_name_list_unprocessed=wordToken.tokenize(button_name)
    for term in button_token_list:
            print(term)
            print(to_xpath(button(term)))
            elemTerm=driver.find_elements_by_xpath(to_xpath(button(term)))
            if len(elemTerm) > 0 and inputFlag==0:              
               if(elemTerm[0].click()==None):      
                   driver.find_element_by_tag_name("body").send_keys(Keys.TAB)
                   print("clicking html term outside locator")
                   break
            elif inputFlag==0:
                elementList=driver.find_elements_by_xpath("//*[contains(text(),'"+term+"')]")
                for ele in elementList: 
                     if(ele.is_displayed() and ele.is_enabled()): 
                        print("in here") 
                        ele.click()
                        inputFlag=1
                        print("entering second last found")
                        break
                        #print("clicking last found")
            elif inputFlag==0:    
                elementList=driver.find_elements_by_xpath("//*[contains(@*,'"+term+"')]")
                for ele in elementList: 
                     if(ele.is_displayed() and ele.is_enabled()): 
                        print("in here") 
                        ele.click()
                        inputFlag=1
                        print("entering last found")
                        break
                        #print("clicking last found")
                     else:
                         print("click last found.Please try different term")                         
                         
                         
                         
                         
def select_checkbox(driver,checkbox_name,checkbox_value):
    wordToken=WordPunctTokenizer()
    input_list=wordToken.tokenize(checkbox_value)
    for term in input_list:
        #term=term.lower()
        print(checkbox_value)
        elem = driver.find_elements_by_xpath(to_xpath(checkbox(checkbox_value)))
        if len(elem) > 0:
           if(elem[0].click()==None):  
               driver.find_element_by_tag_name("body").send_keys(Keys.TAB) 
               print("clicking html checkbox outside locator")
               break
        else:
            print(term)
            print(to_xpath(checkbox(term)))
            elemTerm=driver.find_elements_by_xpath(to_xpath(checkbox(term)))
            if len(elemTerm) > 0:              
               if(elemTerm[0].click()==None):      
                   driver.find_element_by_tag_name("body").send_keys(Keys.TAB)
                   print("clicking html checkbox term outside locator")
                   break
            else:
                elementList=driver.find_elements_by_xpath("//*[contains(text(),'"+term+"')]")
                print("//*[contains(text(),'"+term+"')]")
                print(len(elementList))
                for ele in elementList: 
                     if(ele.is_displayed() and ele.is_enabled() ): 
                        print("in here") 
                        ele.click()
                        break
                     else: 
                        print("no xpath found.Please try different term")                     
def select_radio_button(driver,radio_button_name,radio_button_value):
    wordToken=WordPunctTokenizer()
    input_list=wordToken.tokenize(radio_button_value)
    for term in input_list:
        #term=term.lower()
        print(radio_button_value)
        elem = driver.find_elements_by_xpath(to_xpath(radio_button(radio_button_value)))
        if len(elem) > 0:
           if(elem[0].click()==None):  
               driver.find_element_by_tag_name("body").send_keys(Keys.TAB) 
               print("clicking html checkbox outside locator")
               break
        else:
            print(term)
            print(to_xpath(radio_button(term)))
            elemTerm=driver.find_elements_by_xpath(to_xpath(radio_button(term)))
            if len(elemTerm) > 0:              
               if(elemTerm[0].click()==None):      
                   driver.find_element_by_tag_name("body").send_keys(Keys.TAB)
                   print("clicking html checkbox term outside locator")
                   break
            else:
                elementList=driver.find_elements_by_xpath("//*[contains(text(),'"+term+"')]")
                print("//*[contains(text(),'"+term+"')]")
                print(len(elementList))
                for ele in elementList: 
                     if(ele.is_displayed() and ele.is_enabled() ): 
                        print("in here") 
                        ele.click()
                        break
                     else: 
                        print("no xpath found.Please try different term")                     
def select_Dropdown_value(driver,dropdown_name,dropdown_value):
    inputFlag=0
    dropdown_name_list=dropdown_name.split()
    new_dropdown_name_list=[]
    for term in dropdown_name_list:
        Cap_term=term[0].upper()+("".join(x for x in term[1:]))
        new_dropdown_name_list.append(Cap_term)
    dropdown_name_string=" ".join(x for x in new_dropdown_name_list)
    print(dropdown_name_string) 
    elem = Select(driver.find_element_by_xpath(to_xpath(select(dropdown_name_string))))
    if len(elem) > 0:
       if(elem.select_by_visible_text(dropdown_value)==None): 
         inputFlag=1
         driver.find_element_by_tag_name("body").send_keys(Keys.TAB)
         print("clicking html outside locator")
         
    wordToken=WordPunctTokenizer()
    dropdown_token_list=wordToken.tokenize(dropdown_name)
    dropdown_name_list_unprocessed=wordToken.tokenize(dropdown_name)
    for term in dropdown_token_list:
            print(term)
            print(to_xpath(select(term)))
            elemTerm=Select(driver.find_element_by_xpath(to_xpath(select(term))))
            if len(elemTerm) > 0 and inputFlag==0:              
               if(elemTerm.select_by_visible_text(dropdown_value)==None):      
                   driver.find_element_by_tag_name("body").send_keys(Keys.TAB)
                   print("clicking html term outside locator")
                   break
            elif inputFlag==0:
                elementList=Select(driver.find_elements_by_xpath("//*[contains(text(),'"+term+"')]"))
                for ele in elementList: 
                     if(ele.is_displayed() and ele.is_enabled()): 
                        print("in here") 
                        ele.select_by_visible_text(dropdown_value)
                        print("entering last found")
                        break
                        #print("clicking last found")
            else:    
                print("click last found.Please try different term")                         
                                                                