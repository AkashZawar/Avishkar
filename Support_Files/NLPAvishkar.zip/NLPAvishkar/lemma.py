# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import nltk
from nltk import LancasterStemmer
from nltk.stem import PorterStemmer
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction import stop_words
from nltk.tokenize import word_tokenize,sent_tokenize,WordPunctTokenizer
from sklearn.feature_extraction.text import CountVectorizer
from nltk.corpus import brown
from nltk.corpus import stopwords
from nltk.tokenize import RegexpTokenizer
#print(brown.words()[0:100])
inputData=" ".join(word for word in brown.words()[0:100])
#print(inputData)
reg_tokenize=RegexpTokenizer(r'\w+')
#word_token=word_tokenize(inputData)
reg_tokens=reg_tokenize.tokenize(inputData)
stem=PorterStemmer()
wordLemma=WordNetLemmatizer()
Cv= CountVectorizer(max_df=20, min_df=2)
#print(reg_tokens)
#inputList=word_token[:]
#print(inputList)
#print(wordLemma.lemmatize("churches",pos='n'))
stopword=nltk.corpus.stopwords.words('english')
#print(stopword)
stopword_removed=" ".join(word for word in reg_tokens if word not in stopword )
stopword_removed_tok = word_tokenize(stopword_removed)

Verb_lemmatised_words=[]
for word in stopword_removed_tok:
      Verb_lemmatised_words.append(wordLemma.lemmatize(word,pos='v'))
      print(word+"           "+wordLemma.lemmatize(word,pos='v'))
noun_lemmatised_words=[]   

print("="*100)   
for word in Verb_lemmatised_words:
   noun_lemmatised_words.append(wordLemma.lemmatize(word,pos='n')) 
   print(word+"           "+wordLemma.lemmatize(word,pos='n'))    